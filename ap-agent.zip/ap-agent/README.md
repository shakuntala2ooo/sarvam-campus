# Accounts Payable Agent

An end-to-end **accounts payable automation** prototype: it reads *scanned*
invoices, validates the extracted data, performs a **three-way match** against
purchase orders and goods receipts, applies an **approval policy**, and drives
**payment** through an ERP workflow.

Built to be demoed and then extended — every stage is a separate, testable
module, and the ERP and OCR engines sit behind thin interfaces you can swap.

```
                       ┌─────────────────────────────────────────────────────────┐
  scanned invoice  ──▶ │  1. EXTRACT         2. VALIDATE                         │
  (.png / .jpg)        │  OCR (tesseract) ─▶ parse fields ─▶ sanity-check totals │
                       └──────────────────────────┬──────────────────────────────┘
                                                  ▼
                       ┌─────────────────────────────────────────────────────────┐
                       │  3. THREE-WAY MATCH                                     │
                       │  Invoice  ↔  Purchase Order  ↔  Goods Receipt           │
                       │  → price variance · over/under receipt · duplicates     │
                       └──────────────────────────┬──────────────────────────────┘
                                                  ▼
                       ┌─────────────────────────────────────────────────────────┐
                       │  4. APPROVAL POLICY      5. ERP WORKFLOW                │
                       │  auto-approve ≤ limit  ─▶ post AP document              │
                       │  route / hold / reject ─▶ schedule payment / queue      │
                       └─────────────────────────────────────────────────────────┘
```

---

## What it does (the three capabilities)

**1. Extract and validate invoice data from documents**
`ap_agent/ocr.py` runs tesseract on each scan (grayscale, upscale, autocontrast
pre-processing) in a single pass that yields both text and a confidence score.
`ap_agent/extract.py` parses vendor, GSTIN, invoice number, PO number, dates,
line items and totals, then validates arithmetic (line sum vs subtotal,
subtotal + tax vs total) and records warnings instead of silently trusting bad
reads.

**2. Match invoices with purchase orders and flag discrepancies**
`ap_agent/matching.py` resolves the vendor, finds the PO and the goods receipts,
and runs a **three-way match**. It flags `PRICE_VARIANCE`, `OVER_RECEIPT`,
`UNDER_BILLED`, `MISSING_PO`, `PO_NOT_FOUND`, `PO_CLOSED`, `VENDOR_MISMATCH`,
`TOTAL_VARIANCE` and `DUPLICATE_INVOICE`, each with a severity (INFO / WARN /
ERROR) and a monetary impact. Duplicate detection uses a run-wide registry of
(vendor, invoice number).

**3. Automate approvals and payments through ERP workflows**
`ap_agent/approvals.py` holds the policy: clean invoices under the auto-approval
limit are approved and paid straight through; anything larger is routed to the
right approver by value (line manager → controller → CFO); hard exceptions
(duplicates, missing PO, closed PO) are held. `ap_agent/erp.py` is a mock ERP
connector that posts an AP document, schedules the payment, or queues the item
for approval, and writes a full ledger.

---

## Quick start

```bash
# 1. OCR engine (one-off)
#    Debian/Ubuntu:
sudo apt-get install -y tesseract-ocr
#    macOS:  brew install tesseract
#    (no root? see "Bundling tesseract" below)

# 2. Python deps
pip install -r requirements.txt

# 3. Run the full demo over the sample scanned invoices
python run_demo.py
```

The run prints a summary table and writes `out/report.html`,
`out/processed.json` and `out/erp_ledger.json`.

```bash
python run_demo.py --file data/invoices/01_clean_auto_approve.png   # one scan
python run_demo.py --no-erp                                         # analyse only
python -m unittest discover -s tests                                # unit tests (no OCR)
```

### Bundling tesseract (no root required)
`ap_agent/config.py` looks for the engine in this order: the `TESSERACT_CMD`
environment variable, a vendored `vendor/tesseract/AppRun` (an extracted
[tesseract AppImage](https://github.com/AlexanderP/tesseract-appimage)), then
`tesseract` on `PATH`. So if you can't install system packages you can drop an
extracted AppImage into `vendor/` and the agent will use it:

```bash
curl -L -o t.AppImage https://github.com/AlexanderP/tesseract-appimage/releases/download/v5.5.3/tesseract-5.5.3_lept-1.84-x86_64.AppImage
chmod +x t.AppImage && ./t.AppImage --appimage-extract
mkdir -p vendor && mv squashfs-root vendor/tesseract
```

---

## Demo scenarios

`tools/generate_invoices.py` renders eight realistic **scanned** invoices
(slight rotation, blur and scanner noise) plus a `data/ground_truth.json`, so
the demo scores its own extraction accuracy. They cover every branch of the
policy:

| # | Invoice | Scenario | Outcome |
|---|---------|----------|---------|
| 01 | INV-2024-0912 | clean match, small | **auto-approved**, payment scheduled |
| 02 | INV-2024-0918 | unit price 5% over PO | routed → line manager |
| 03 | INV-2024-0921 | invoiced 60, only 50 received | exception → routed |
| 04 | INV-2024-0925 | no PO referenced | manual coding |
| 05 | INV-2024-0912 (again) | duplicate submission | **held** |
| 06 | INV-2024-0930 | clean but above auto-limit | routed → line manager |
| 07 | INV-2024-0933 | PO already closed | held → procurement |
| 08 | INV-2024-0936 | clean, high value | routed → controller |

Extraction accuracy against ground truth on this set: **100%** for invoice
number, PO number, vendor name and total amount.

---

## Project layout

```
ap-agent/
├── run_demo.py               # CLI entry point
├── ap_agent/
│   ├── config.py             # tolerances, approval limits, paths, OCR settings
│   ├── ocr.py                # tesseract wrapper + preprocessing
│   ├── extract.py            # OCR text → validated Invoice
│   ├── models.py             # dataclasses (Invoice, PO, GRN, MatchResult, …)
│   ├── matching.py           # three-way match + discrepancy detection
│   ├── approvals.py          # approval policy
│   ├── erp.py                # mock ERP connector + ledger
│   ├── pipeline.py           # orchestration (load → process → post)
│   └── report.py             # console summary + HTML dashboard
├── tools/
│   ├── generate_invoices.py  # synthetic scanned invoice generator
│   └── rebuild_report.py     # rebuild dashboard from processed.json
├── data/                     # vendors, POs, goods receipts, invoices, truth
└── tests/test_agent.py       # unit tests (extraction, matching, approvals)
```

---

## Tuning the policy

Everything a finance team would want to change lives in `ap_agent/config.py`:

| Setting | Meaning |
|---------|---------|
| `PRICE_TOLERANCE_PCT` | allowed unit-price drift before a variance is raised (default 2%) |
| `QTY_TOLERANCE_UNITS` | allowed over/under receipt (default 0) |
| `AUTO_APPROVE_LIMIT` | value below which a clean invoice is paid touchlessly |
| `MANAGER_APPROVE_LIMIT` / `CONTROLLER_APPROVE_LIMIT` | approval tiers by value |
| `HARD_EXCEPTION_TYPES` | discrepancy codes that always block auto-approval |
| `OCR_PSM` | tesseract page-segmentation mode (4 suits invoices) |

---

## Extending to production

- **Real ERP**: replace `ap_agent/erp.py` with a client for SAP (BAPI/OData),
  Oracle Fusion, NetSuite or Tally. The rest of the pipeline calls only
  `post_invoice`, `schedule_payment` and `enqueue_for_approval`.
- **More OCR**: `ap_agent/ocr.py` exposes `read_image(path) -> OCRResult`.
  Swap in a cloud document-AI service or a fine-tuned model without touching
  the parser.
- **Learning**: the discrepancy records are structured and labelled, so they
  are ready to train a tolerance/risk model or feed an analyst feedback loop.

---

## Notes & limitations

- The ERP, vendor/PO/GRN masters and invoices are **synthetic** — no real
  financial data is used.
- The extraction parser targets the invoice layout produced by the generator.
  Real vendor invoices vary; the parser is deliberately tolerant and flags
  uncertainty, but production use should add per-vendor templates.
- Payment scheduling posts to a mock ledger only; no money moves.
