"""Accounts Payable Agent — extraction, three-way matching, approvals, ERP posting."""
__version__ = "1.0.0"
