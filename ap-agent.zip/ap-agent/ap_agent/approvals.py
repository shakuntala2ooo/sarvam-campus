"""Approval policy.

Turns a MatchResult + invoice value into an actionable Decision:
auto-approve, route to a specific approver role, hold, or reject. This is
where the *policy* lives — the code that a finance team would tune.
"""
from __future__ import annotations

from datetime import date, timedelta

from . import config
from .models import Decision, Invoice, MatchResult, Vendor


def _approver_for_amount(total: float) -> str:
    if total <= config.AUTO_APPROVE_LIMIT:
        return ""                      # no human needed
    if total <= config.MANAGER_APPROVE_LIMIT:
        return "LINE_MANAGER"
    if total <= config.CONTROLLER_APPROVE_LIMIT:
        return "CONTROLLER"
    return "CFO"


def _payment_date(inv: Invoice, vendor: Vendor | None) -> tuple[str, bool]:
    """Return (pay_date, overdue). Falls back to terms when no due date."""
    today = date.today()
    due = None
    if inv.due_date:
        try:
            due = date.fromisoformat(inv.due_date)
        except ValueError:
            due = None
    if due is None and inv.invoice_date:
        try:
            terms = vendor.payment_terms_days if vendor else config.DEFAULT_PAYMENT_TERMS_DAYS
            due = date.fromisoformat(inv.invoice_date) + timedelta(days=terms)
        except ValueError:
            due = None
    if due is None:
        due = today + timedelta(days=config.DEFAULT_PAYMENT_TERMS_DAYS)
    return due.isoformat(), due < today


def decide(inv: Invoice, match: MatchResult, vendor: Vendor | None) -> Decision:
    d = Decision()
    codes = {x.code for x in match.discrepancies}
    errors = [x for x in match.discrepancies if x.severity == "ERROR"]
    warns = [x for x in match.discrepancies if x.severity == "WARN"]

    # 1. hard stops ------------------------------------------------------
    if "DUPLICATE_INVOICE" in codes:
        d.action = "HELD"
        d.reasons = ["Duplicate submission — same vendor + invoice number already processed"]
        d.payment_status = "BLOCKED"
        d.approver_role = "AP_ANALYST"
        return d

    if "MISSING_PO" in codes:
        d.action = "MANUAL_CODING"
        d.reasons = ["No purchase order referenced — needs manual coding / non-PO approval"]
        d.payment_status = "BLOCKED"
        d.approver_role = "AP_ANALYST"
        return d

    if "PO_CLOSED" in codes:
        d.action = "HELD"
        d.reasons = ["Referenced purchase order is closed — procurement must re-open or reject"]
        d.payment_status = "BLOCKED"
        d.approver_role = "PROCUREMENT"
        return d

    if "PO_NOT_FOUND" in codes or "VENDOR_NOT_FOUND" in codes:
        d.action = "ROUTED"
        d.reasons = [x.detail for x in errors]
        d.approver_role = "AP_ANALYST"
        d.payment_status = "BLOCKED"
        return d

    # 2. quantity / price exceptions ------------------------------------
    if errors:
        role = _approver_for_amount(inv.total) or "LINE_MANAGER"
        d.action = "ROUTED"
        d.approver_role = role
        d.reasons = [f"{x.code}: {x.detail}" for x in errors]
        d.payment_status = "BLOCKED"
        return d

    # 3. soft exceptions (warnings) -------------------------------------
    if warns:
        d.action = "ROUTED"
        d.approver_role = _approver_for_amount(inv.total) or "LINE_MANAGER"
        d.reasons = [f"{x.code}: {x.detail}" for x in warns]
        d.payment_status = "BLOCKED"
        return d

    # 4. clean match — tiered approval by value -------------------------
    role = _approver_for_amount(inv.total)
    if role == "":
        d.action = "AUTO_APPROVED"
        d.reasons = ["Clean three-way match; within auto-approval limit"]
        pay_date, overdue = _payment_date(inv, vendor)
        d.payment_date = pay_date
        d.payment_status = "SCHEDULED"
        if overdue:
            d.reasons.append("Payment date already elapsed — scheduled for immediate release")
    else:
        d.action = "ROUTED"
        d.approver_role = role
        d.reasons = [f"Clean match but value exceeds auto-approval limit; needs {role} sign-off"]
        d.payment_status = "BLOCKED"
    return d
