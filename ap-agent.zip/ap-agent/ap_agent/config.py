"""Central configuration for the Accounts Payable Agent.

All business thresholds, tolerances and paths live here so that the
matching/approval behaviour can be tuned without touching logic.
"""
from __future__ import annotations

import os
from pathlib import Path

# --------------------------------------------------------------------------
# Paths
# --------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_ROOT / "data"
INVOICE_DIR = DATA_DIR / "invoices"
OUT_DIR = PROJECT_ROOT / "out"

# --------------------------------------------------------------------------
# OCR backend
# --------------------------------------------------------------------------
# The sandbox ships tesseract as an extracted AppImage under vendor/.
# AppRun is a launcher that sets up the bundled shared libraries.
# Override with the TESSERACT_CMD env var if tesseract is on PATH.
_DEFAULT_APPIMAGE = PROJECT_ROOT / "vendor" / "tesseract" / "AppRun"
TESSERACT_CMD = os.environ.get(
    "TESSERACT_CMD",
    str(_DEFAULT_APPIMAGE) if _DEFAULT_APPIMAGE.exists() else "tesseract",
)
TESSDATA_PREFIX = os.environ.get(
    "TESSDATA_PREFIX",
    str(PROJECT_ROOT / "vendor" / "tesseract" / "usr" / "share" / "tesseract-ocr" / "5" / "tessdata"),
)
OCR_LANG = "eng"
# PSM 4 = single column of text of variable sizes. Better than PSM 6 for
# invoices: PSM 6 treats the page as one uniform block and silently drops
# the isolated vendor-name line at the top of the scan.
OCR_PSM = 4

# --------------------------------------------------------------------------
# Matching tolerances  (three-way match: Invoice vs PO vs Goods Receipt)
# --------------------------------------------------------------------------
# Relative price tolerance: |invoice_unit_price - po_unit_price| / po_unit_price
PRICE_TOLERANCE_PCT = 0.02          # 2 %
# Absolute quantity short/over receipt tolerance (units)
QTY_TOLERANCE_UNITS = 0
# Absolute total tolerance (currency units) applied before a line-level check
TOTAL_TOLERANCE_ABS = 1.00
# Relative total tolerance
TOTAL_TOLERANCE_PCT = 0.005         # 0.5 %

# --------------------------------------------------------------------------
# Approval policy
# --------------------------------------------------------------------------
# Below this amount a clean invoice is auto-approved and auto-paid.
AUTO_APPROVE_LIMIT = 100_000.00     # INR
# Clean invoices between auto-approve and this limit need a line manager.
MANAGER_APPROVE_LIMIT = 500_000.00  # INR
# Clean invoices above this need a controller / CFO.
CONTROLLER_APPROVE_LIMIT = 2_000_000.00

# Any invoice carrying a hard exception is never auto-approved.
HARD_EXCEPTION_TYPES = {
    "DUPLICATE_INVOICE",
    "VENDOR_MISMATCH",
    "MISSING_PO",
    "OVER_RECEIPT",
    "PO_CLOSED",
}

CURRENCY = "INR"
CURRENCY_SYMBOL = "\u20b9"  # ₹

# Default vendor payment terms when the master record does not specify them.
DEFAULT_PAYMENT_TERMS_DAYS = 30
