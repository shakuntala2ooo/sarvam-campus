"""Mock ERP connector.

Stands in for SAP / Oracle / Tally. It exposes the two calls the agent
needs — post the invoice and schedule the payment — and keeps a ledger so
the demo can show what would have landed in the ERP.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path

from .models import Decision, Invoice, Vendor


@dataclass
class ERPEntry:
    erp_document: str
    invoice_number: str
    vendor_name: str
    amount: float
    action: str
    payment_status: str
    payment_date: str = ""
    payment_ref: str = ""
    posted_at: str = ""
    note: str = ""


class MockERP:
    """In-memory ERP with a JSON ledger written to out/erp_ledger.json."""

    def __init__(self) -> None:
        self._doc_seq = 10240
        self._pay_seq = 7700
        self.entries: list[ERPEntry] = []
        self.queue: list[dict] = []      # routed items awaiting approval

    def _next_doc(self) -> str:
        self._doc_seq += 1
        return f"ERP-AP-{self._doc_seq}"

    def _next_pay(self) -> str:
        self._pay_seq += 1
        return f"PAY-2026-{self._pay_seq}"

    # ------------------------------------------------------------------
    def post_invoice(self, inv: Invoice, dec: Decision, vendor: Vendor | None) -> ERPEntry:
        """Create the AP document. Clean invoices post as an open liability;
        exceptions post as a blocked/held document."""
        doc = self._next_doc()
        entry = ERPEntry(
            erp_document=doc,
            invoice_number=inv.invoice_number,
            vendor_name=vendor.name if vendor else inv.vendor_name,
            amount=inv.total,
            action=dec.action,
            payment_status=dec.payment_status,
            payment_date=dec.payment_date,
            posted_at=date.today().isoformat(),
            note="; ".join(dec.reasons[:1]),
        )
        dec.erp_document = doc
        self.entries.append(entry)
        return entry

    def schedule_payment(self, entry: ERPEntry) -> str:
        if entry.payment_status != "SCHEDULED":
            return ""
        ref = self._next_pay()
        entry.payment_ref = ref
        return ref

    def enqueue_for_approval(self, entry: ERPEntry, dec: Decision) -> None:
        self.queue.append({
            "erp_document": entry.erp_document,
            "invoice_number": entry.invoice_number,
            "vendor": entry.vendor_name,
            "amount": entry.amount,
            "approver_role": dec.approver_role,
            "reasons": dec.reasons,
        })

    # ------------------------------------------------------------------
    def summary(self) -> dict:
        scheduled = [e for e in self.entries if e.payment_status == "SCHEDULED"]
        blocked = [e for e in self.entries if e.payment_status == "BLOCKED"]
        return {
            "documents_posted": len(self.entries),
            "payments_scheduled": len(scheduled),
            "payments_blocked": len(blocked),
            "value_scheduled": round(sum(e.amount for e in scheduled), 2),
            "value_blocked": round(sum(e.amount for e in blocked), 2),
            "approval_queue": len(self.queue),
        }

    def save(self, path: str | Path) -> None:
        payload = {
            "generated_at": date.today().isoformat(),
            "summary": self.summary(),
            "entries": [e.__dict__ for e in self.entries],
            "approval_queue": self.queue,
        }
        Path(path).write_text(json.dumps(payload, indent=2))
