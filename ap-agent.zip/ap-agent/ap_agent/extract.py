"""Turn raw OCR text into a structured, validated Invoice.

The parser is deliberately tolerant: invoices come from many vendors and
OCR introduces noise, so every field has a primary pattern and at least
one fallback, and validation flags (rather than discards) anything odd.
"""
from __future__ import annotations

import re
from datetime import date

from .models import Invoice, InvoiceLine
from .ocr import OCRResult

# --------------------------------------------------------------------------
# regexes
# --------------------------------------------------------------------------
RE_INV_NO = re.compile(r"invoice\s*(?:no|number|#)\s*[.:]?\s*([A-Za-z0-9][A-Za-z0-9\-/]{3,})", re.I)
RE_INV_NO_FB = re.compile(r"\b(INV[-\s]?\d{4}[-\s]?\d{3,4})\b", re.I)
RE_PO = re.compile(r"\bPO[-\s]?(\d{3,6})\b", re.I)
RE_GSTIN = re.compile(r"\b(\d{2}[A-Z]{5}\d{4}[A-Z]\d[A-Z]\d)\b")
RE_ISO_DATE = re.compile(r"\b(\d{4}-\d{2}-\d{2})\b")
RE_DMY = re.compile(r"\b(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})\b")
RE_DMONY = re.compile(r"\b(\d{1,2}[\s-][A-Za-z]{3,9}[\s-]\d{2,4})\b")
RE_AMOUNT = re.compile(r"(\d[\d,]*(?:\.\d{1,2})?)")
RE_ROW = re.compile(
    r"^(?P<desc>.*[A-Za-z].*?)\s+(?P<qty>[A-Za-z0-9]{1,6})\s+"
    r"(?P<up>\d[\d,]*(?:\.\d{1,2})?)\s+(?P<amt>\d[\d,]*(?:\.\d{1,2})?)$"
)
# OCR frequently turns a thin "1" into "l"/"al"/"I"; normalise qty.
_QTY_MAP = str.maketrans({"O": "0", "o": "0", "l": "1", "I": "1", "S": "5", "B": "8"})

_MONTHS = {m: i + 1 for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"])}


def _to_qty(tok: str) -> float:
    digits = re.sub(r"[^0-9.]", "", tok.translate(_QTY_MAP))
    if not digits:
        return 1.0  # single-item service line where qty glyph was lost
    try:
        return float(digits)
    except ValueError:
        return 1.0


def _to_float(s: str) -> float:
    try:
        return float(s.replace(",", "").replace("\u20b9", "").strip())
    except (ValueError, AttributeError):
        return 0.0


def _find_amount(line: str) -> float:
    nums = RE_AMOUNT.findall(line)
    return _to_float(nums[-1]) if nums else 0.0


def _norm_date(s: str) -> str:
    s = s.strip()
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", s):
        return s
    m = re.fullmatch(r"(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})", s)
    if m:
        d, mo, y = (int(x) for x in m.groups())
        y = y + 2000 if y < 100 else y
        try:
            return date(y, mo, d).isoformat()
        except ValueError:
            return ""
    m = re.fullmatch(r"(\d{1,2})[\s-]([A-Za-z]{3,9})[\s-](\d{2,4})", s)
    if m:
        d = int(m.group(1))
        mo = _MONTHS.get(m.group(2)[:3].lower())
        y = int(m.group(3))
        y = y + 2000 if y < 100 else y
        if mo:
            try:
                return date(y, mo, d).isoformat()
            except ValueError:
                return ""
    return ""


def _clean_desc(desc: str) -> str:
    # drop leading OCR junk characters
    return re.sub(r"^[^\w(]+", "", desc).strip()


def _looks_like_header(line: str) -> bool:
    low = line.lower()
    return ("description" in low and "qty" in low) or low.strip() in {"description", "amount"}


def _is_totals_line(line: str) -> bool:
    low = line.lower()
    return any(k in low for k in ("subtotal", "sub total", "gst", "tax", "total", "payment terms",
                                  "bank", "authorised", "authorized", "signatory"))


def extract(ocr: OCRResult, source_file: str = "") -> Invoice:
    text = ocr.text
    lines = ocr.lines
    warnings: list[str] = []

    inv = Invoice(source_file=source_file, raw_text=text, ocr_confidence=ocr.confidence)

    # ---- header fields -------------------------------------------------
    m = RE_INV_NO.search(text) or RE_INV_NO_FB.search(text)
    if m:
        inv.invoice_number = m.group(1).upper().replace(" ", "")
    else:
        warnings.append("invoice_number not found")

    m = RE_PO.search(text)
    if m:
        inv.po_number = f"PO-{m.group(1)}"
    else:
        warnings.append("po_number not found")

    m = RE_GSTIN.search(text)
    if m:
        inv.vendor_gstin = m.group(1)

    # vendor name = first substantial non-title line
    for ln in lines[:3]:
        if ln.upper() != "TAX INVOICE" and len(ln) > 3 and not RE_ISO_DATE.search(ln):
            inv.vendor_name = ln.strip()
            break

    # dates: look at the labelled lines first, else any date
    for ln in lines:
        low = ln.lower()
        if "invoice date" in low or ("date" in low and "due" not in low and "invoice" in low):
            m = RE_ISO_DATE.search(ln) or RE_DMY.search(ln) or RE_DMONY.search(ln)
            if m:
                inv.invoice_date = _norm_date(m.group(1))
        if "due date" in low:
            m = RE_ISO_DATE.search(ln) or RE_DMY.search(ln) or RE_DMONY.search(ln)
            if m:
                inv.due_date = _norm_date(m.group(1))
    if not inv.invoice_date:
        m = RE_ISO_DATE.search(text)
        if m:
            inv.invoice_date = _norm_date(m.group(1))

    # ---- totals --------------------------------------------------------
    for ln in lines:
        low = ln.lower()
        if "sub" in low and "total" in low:
            inv.subtotal = _find_amount(ln)
        elif ("gst" in low or "tax" in low) and "total" not in low:
            inv.tax = _find_amount(ln)
        elif re.search(r"\btotal\b", low) and "sub" not in low:
            inv.total = _find_amount(ln)

    # ---- line items ----------------------------------------------------
    in_table = False
    for ln in lines:
        if _looks_like_header(ln):
            in_table = True
            continue
        if not in_table:
            continue
        if _is_totals_line(ln):
            in_table = False
            continue
        m = RE_ROW.match(ln)
        if m:
            inv.lines.append(InvoiceLine(
                description=_clean_desc(m.group("desc")),
                qty=_to_qty(m.group("qty")),
                unit_price=_to_float(m.group("up")),
                amount=_to_float(m.group("amt")),
            ))

    # ---- validation ----------------------------------------------------
    if not inv.lines:
        warnings.append("no line items parsed")
    if inv.total <= 0:
        warnings.append("total not found")
    if inv.subtotal and inv.lines:
        s = round(sum(l.amount for l in inv.lines), 2)
        if abs(s - inv.subtotal) > max(1.0, 0.01 * inv.subtotal):
            warnings.append(f"line items sum {s} != subtotal {inv.subtotal}")
    if inv.subtotal and inv.tax and inv.total:
        if abs((inv.subtotal + inv.tax) - inv.total) > 1.0:
            warnings.append("subtotal + tax != total")

    inv.extraction_warnings = warnings
    return inv
