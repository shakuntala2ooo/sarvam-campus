"""Three-way matching: Invoice  <->  Purchase Order  <->  Goods Receipt.

Produces a MatchResult carrying every discrepancy it finds, each with a
severity, so the approval layer can decide what to do without re-deriving
anything.
"""
from __future__ import annotations

import re
from difflib import SequenceMatcher

from . import config
from .models import (Discrepancy, GoodsReceipt, Invoice, InvoiceLine,
                     MatchResult, PurchaseOrder, Vendor)


def _norm_name(s: str) -> str:
    s = re.sub(r"\b(pvt|private|ltd|limited|co|company|inc|llp)\b", "", s.lower())
    return re.sub(r"[^a-z0-9]", "", s)


def _similar(a: str, b: str) -> float:
    return SequenceMatcher(None, _norm_name(a), _norm_name(b)).ratio()


def resolve_vendor(inv: Invoice, vendors: dict[str, Vendor]) -> tuple[Vendor | None, float]:
    """Find the vendor master record for an invoice, by GSTIN then name."""
    if inv.vendor_gstin:
        for v in vendors.values():
            if v.gstin and v.gstin.upper() == inv.vendor_gstin.upper():
                return v, 1.0
    best, score = None, 0.0
    for v in vendors.values():
        s = _similar(inv.vendor_name, v.name)
        if s > score:
            best, score = v, s
    return (best, score) if score >= 0.6 else (None, score)


def _grn_received(po_number: str, grns: dict[str, GoodsReceipt]) -> dict[str, float]:
    rec: dict[str, float] = {}
    for g in grns.values():
        if g.po_number == po_number:
            for l in g.lines:
                rec[l.sku] = rec.get(l.sku, 0.0) + l.qty_received
    return rec


def _match_lines(po: PurchaseOrder, inv: Invoice) -> list[tuple]:
    """Greedy best-similarity pairing of invoice lines to PO lines."""
    pairs, used = [], set()
    for il in inv.lines:
        best_i, best_s = None, 0.0
        for i, pl in enumerate(po.lines):
            if i in used:
                continue
            s = _similar(il.description, pl.description)
            if s > best_s:
                best_i, best_s = i, s
        if best_i is not None and best_s >= 0.5:
            used.add(best_i)
            pairs.append((il, po.lines[best_i], best_s))
        else:
            pairs.append((il, None, best_s))
    return pairs


def match(inv: Invoice, vendors: dict[str, Vendor], pos: dict[str, PurchaseOrder],
          grns: dict[str, GoodsReceipt], seen: dict[tuple, str] | None = None) -> MatchResult:
    """Match one invoice. `seen` is a duplicate registry keyed by
    (vendor_key, invoice_number) -> source_file of the first sighting."""
    res = MatchResult()
    disc = res.discrepancies

    # ---- duplicate detection ------------------------------------------
    if seen is not None and inv.invoice_number:
        vkey = _norm_name(inv.vendor_name) or (inv.vendor_gstin or "?")
        key = (vkey, inv.invoice_number.upper())
        if key in seen:
            disc.append(Discrepancy(
                "DUPLICATE_INVOICE", "ERROR",
                f"Invoice {inv.invoice_number} from {inv.vendor_name} was already "
                f"processed as {seen[key]}", 0.0))
        else:
            seen[key] = inv.source_file

    # ---- vendor --------------------------------------------------------
    vendor, vscore = resolve_vendor(inv, vendors)
    if vendor is None:
        disc.append(Discrepancy("VENDOR_NOT_FOUND", "ERROR",
                                f"No vendor master record for '{inv.vendor_name}'", 0.0))

    # ---- PO presence & lookup -----------------------------------------
    po = None
    if not inv.po_number:
        disc.append(Discrepancy("MISSING_PO", "ERROR",
                                "Invoice references no purchase order", 0.0))
        res.match_status = "NO_PO"
    else:
        po = pos.get(inv.po_number)
        if po is None:
            disc.append(Discrepancy("PO_NOT_FOUND", "ERROR",
                                    f"Purchase order {inv.po_number} not found in ERP", 0.0))
        else:
            res.matched_po = po.po_number
            if po.status != "OPEN":
                disc.append(Discrepancy("PO_CLOSED", "ERROR",
                                        f"Purchase order {po.po_number} is {po.status}", 0.0))
            if vendor and po.vendor_id != vendor.vendor_id:
                disc.append(Discrepancy(
                    "VENDOR_MISMATCH", "ERROR",
                    f"PO {po.po_number} is raised on {po.vendor_name}, invoice is from "
                    f"{inv.vendor_name}", 0.0))

    # ---- line-level three-way comparison ------------------------------
    if po is not None:
        received = _grn_received(po.po_number, grns)
        for g in grns.values():
            if g.po_number == po.po_number:
                res.matched_grns.append(g.grn_number)

        for il, pl, sim in _match_lines(po, inv):
            if pl is None:
                disc.append(Discrepancy("UNMATCHED_LINE", "WARN",
                                        f"Invoice line '{il.description}' has no PO line", il.amount))
                continue
            # price variance
            if pl.unit_price:
                var = (il.unit_price - pl.unit_price) / pl.unit_price
                if abs(var) > config.PRICE_TOLERANCE_PCT:
                    sev = "ERROR" if abs(var) > 0.05 else "WARN"
                    disc.append(Discrepancy(
                        "PRICE_VARIANCE", sev,
                        f"'{pl.description}': billed {il.unit_price:,.2f} vs PO "
                        f"{pl.unit_price:,.2f} ({var:+.1%})",
                        round((il.unit_price - pl.unit_price) * il.qty, 2)))
            # quantity vs goods receipt
            rec = received.get(pl.sku, pl.qty)
            if il.qty > rec + config.QTY_TOLERANCE_UNITS:
                disc.append(Discrepancy(
                    "OVER_RECEIPT", "ERROR",
                    f"'{pl.description}': invoiced {il.qty:g} but only {rec:g} received",
                    round((il.qty - rec) * pl.unit_price, 2)))
            elif il.qty < rec - config.QTY_TOLERANCE_UNITS:
                disc.append(Discrepancy(
                    "UNDER_BILLED", "WARN",
                    f"'{pl.description}': invoiced {il.qty:g} vs {rec:g} received",
                    round((il.qty - rec) * pl.unit_price, 2)))

        # PO lines that never appeared on the invoice
        billed = {id(pl) for _, pl, _ in _match_lines(po, inv) if pl is not None}
        for pl in po.lines:
            if id(pl) not in billed:
                disc.append(Discrepancy("UNBILLED_PO_LINE", "INFO",
                                        f"PO line '{pl.description}' not on this invoice", 0.0))

        # total-level sanity
        exp_total = round(po.expected_total * (1 + 0.18), 2)
        if inv.total and abs(inv.total - exp_total) > max(config.TOTAL_TOLERANCE_ABS,
                                                          config.TOTAL_TOLERANCE_PCT * exp_total):
            # only flag if no line-level price variance already explains it
            if not any(d.code == "PRICE_VARIANCE" for d in disc):
                disc.append(Discrepancy("TOTAL_VARIANCE", "WARN",
                                        f"Invoice total {inv.total:,.2f} vs expected {exp_total:,.2f}",
                                        round(inv.total - exp_total, 2)))

    # ---- status & confidence ------------------------------------------
    if res.match_status != "NO_PO":
        if any(d.severity == "ERROR" for d in disc):
            res.match_status = "EXCEPTION"
        elif any(d.severity == "WARN" for d in disc):
            res.match_status = "PARTIAL"
        elif po is not None:
            res.match_status = "MATCHED"
        else:
            res.match_status = "UNMATCHED"

    line_scores = []
    if po is not None:
        line_scores = [s for _, _, s in _match_lines(po, inv)]
    field_score = sum(bool(x) for x in [inv.invoice_number, inv.vendor_name,
                                        inv.po_number, inv.total]) / 4
    line_score = (sum(line_scores) / len(line_scores)) if line_scores else 0.0
    res.confidence = round(0.5 * field_score + 0.5 * line_score, 3)
    return res
