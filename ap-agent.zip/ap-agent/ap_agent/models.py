"""Domain model for the Accounts Payable Agent.

Plain dataclasses so the whole pipeline is easy to serialise, inspect and
unit-test. Nothing here talks to the outside world.
"""
from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field, asdict
from datetime import date
from typing import Any, Optional


# --------------------------------------------------------------------------
# Master data
# --------------------------------------------------------------------------
@dataclass
class Vendor:
    vendor_id: str
    name: str
    gstin: str = ""
    payment_terms_days: int = 30
    bank_account: str = ""
    active: bool = True


@dataclass
class POLine:
    sku: str
    description: str
    qty: float
    unit_price: float


@dataclass
class PurchaseOrder:
    po_number: str
    vendor_id: str
    vendor_name: str
    po_date: str
    currency: str
    lines: list[POLine] = field(default_factory=list)
    status: str = "OPEN"          # OPEN | CLOSED | CANCELLED
    buyer: str = ""

    @property
    def expected_total(self) -> float:
        return round(sum(l.qty * l.unit_price for l in self.lines), 2)


@dataclass
class GRNLine:
    sku: str
    qty_received: float


@dataclass
class GoodsReceipt:
    grn_number: str
    po_number: str
    receipt_date: str
    lines: list[GRNLine] = field(default_factory=list)


# --------------------------------------------------------------------------
# Extracted invoice
# --------------------------------------------------------------------------
@dataclass
class InvoiceLine:
    description: str
    qty: float = 0.0
    unit_price: float = 0.0
    amount: float = 0.0
    sku: Optional[str] = None


@dataclass
class Invoice:
    # provenance
    source_file: str = ""
    # header fields (extracted)
    invoice_number: str = ""
    invoice_date: str = ""
    due_date: str = ""
    vendor_name: str = ""
    vendor_gstin: str = ""
    po_number: str = ""
    currency: str = "INR"
    subtotal: float = 0.0
    tax: float = 0.0
    total: float = 0.0
    lines: list[InvoiceLine] = field(default_factory=list)
    # extraction bookkeeping
    ocr_confidence: float = 0.0
    extraction_warnings: list[str] = field(default_factory=list)
    raw_text: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# --------------------------------------------------------------------------
# Matching
# --------------------------------------------------------------------------
@dataclass
class Discrepancy:
    code: str          # e.g. PRICE_VARIANCE
    severity: str      # INFO | WARN | ERROR
    detail: str
    delta: float = 0.0  # signed monetary or quantity impact


@dataclass
class MatchResult:
    match_status: str = "UNMATCHED"   # MATCHED | PARTIAL | EXCEPTION | NO_PO
    matched_po: Optional[str] = None
    matched_grns: list[str] = field(default_factory=list)
    discrepancies: list[Discrepancy] = field(default_factory=list)
    confidence: float = 0.0

    @property
    def has_errors(self) -> bool:
        return any(d.severity == "ERROR" for d in self.discrepancies)


# --------------------------------------------------------------------------
# Decision / workflow
# --------------------------------------------------------------------------
@dataclass
class Decision:
    action: str = ""                 # AUTO_APPROVED | ROUTED | HELD | REJECTED | MANUAL_CODING
    approver_role: str = ""          # "" | LINE_MANAGER | CONTROLLER | CFO
    reasons: list[str] = field(default_factory=list)
    payment_status: str = "NOT_SCHEDULED"   # NOT_SCHEDULED | SCHEDULED | BLOCKED
    payment_date: str = ""
    erp_document: str = ""
    audit: list[str] = field(default_factory=list)


@dataclass
class ProcessedInvoice:
    invoice: Invoice
    match: MatchResult
    decision: Decision
    vendor: Optional[Vendor] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "invoice": self.invoice.to_dict(),
            "match": asdict(self.match),
            "decision": asdict(self.decision),
            "vendor": asdict(self.vendor) if self.vendor else None,
        }
