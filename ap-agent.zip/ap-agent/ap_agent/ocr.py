"""OCR backend.

Wraps tesseract (via pytesseract) behind a tiny interface so the rest of
the pipeline never touches the OCR engine directly. Includes a light
pre-processing pass that reliably helps scanned invoices.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field

import pytesseract
from PIL import Image, ImageOps

from . import config

# Point pytesseract at the bundled/available engine exactly once.
pytesseract.pytesseract.tesseract_cmd = config.TESSERACT_CMD
if config.TESSDATA_PREFIX:
    os.environ.setdefault("TESSDATA_PREFIX", config.TESSDATA_PREFIX)


@dataclass
class OCRResult:
    text: str
    confidence: float                       # 0..100 mean word confidence
    word_count: int = 0
    lines: list[str] = field(default_factory=list)


def _preprocess(img: Image.Image) -> Image.Image:
    """Grayscale + upscale + autocontrast. Upscaling small scans is the
    single biggest accuracy win for tesseract."""
    img = img.convert("L")
    w, h = img.size
    if w < 1600:
        scale = 1600 / w
        img = img.resize((int(w * scale), int(h * scale)), Image.LANCZOS)
    img = ImageOps.autocontrast(img, cutoff=1)
    return img


def read_image(path: str) -> OCRResult:
    """OCR an invoice image in a single tesseract pass.

    We use the word-level TSV output and rebuild lines from it, so text
    and confidence come from one invocation (roughly half the cost of
    calling image_to_string + image_to_data separately).
    """
    img = Image.open(path)
    proc = _preprocess(img)
    cfg = f"--oem 3 --psm {config.OCR_PSM}"
    data = pytesseract.image_to_data(
        proc, lang=config.OCR_LANG, config=cfg,
        output_type=pytesseract.Output.DICT,
    )

    confs = [float(c) for c in data["conf"] if str(c) not in ("-1", "")]
    conf = sum(confs) / len(confs) if confs else 0.0

    # group words into lines by (block, paragraph, line)
    buckets: dict[tuple, list[str]] = {}
    for i, word in enumerate(data["text"]):
        if not word.strip():
            continue
        key = (data["block_num"][i], data["par_num"][i], data["line_num"][i])
        buckets.setdefault(key, []).append(word.strip())
    lines = [" ".join(buckets[k]) for k in sorted(buckets)]
    words = sum(len(v) for v in buckets.values())
    return OCRResult(text="\n".join(lines), confidence=round(conf, 1),
                     word_count=words, lines=lines)


class OCREngineError(RuntimeError):
    """Raised when the tesseract engine cannot be located."""


def ensure_engine() -> None:
    """Fail early with an actionable message if tesseract is missing."""
    try:
        pytesseract.get_tesseract_version()
    except Exception as e:  # pragma: no cover
        raise OCREngineError(
            "tesseract OCR engine not found.\n"
            "  - install it:  sudo apt-get install tesseract-ocr   (or brew install tesseract)\n"
            "  - or point at an existing binary:  export TESSERACT_CMD=/path/to/tesseract\n"
            "  - or vendor an AppImage into vendor/tesseract/ (see README)"
        ) from e


def engine_info() -> str:
    try:
        v = pytesseract.get_tesseract_version()
        return f"tesseract {v}"
    except Exception as e:  # pragma: no cover
        return f"tesseract unavailable ({e})"
