"""End-to-end orchestration.

load master data -> for each invoice: OCR -> extract -> match -> decide
-> post to ERP -> schedule payment. Returns fully-traced results.
"""
from __future__ import annotations

import json
from pathlib import Path

from . import approvals, config, erp, extract, matching, ocr
from .models import (GoodsReceipt, GRNLine, POLine, ProcessedInvoice,
                     PurchaseOrder, Vendor)


# --------------------------------------------------------------------------
# master data
# --------------------------------------------------------------------------
def load_master(data_dir: Path | None = None):
    data_dir = data_dir or config.DATA_DIR
    vendors = {
        vid: Vendor(**v)
        for vid, v in json.loads((data_dir / "vendors.json").read_text()).items()
    }
    pos = {}
    for pn, p in json.loads((data_dir / "purchase_orders.json").read_text()).items():
        p = dict(p)
        lines = [POLine(**l) for l in p.pop("lines")]
        pos[pn] = PurchaseOrder(**p, lines=lines)
    grns = {}
    for gn, g in json.loads((data_dir / "goods_receipts.json").read_text()).items():
        g = dict(g)
        lines = [GRNLine(**l) for l in g.pop("lines")]
        grns[gn] = GoodsReceipt(**g, lines=lines)
    return vendors, pos, grns


# --------------------------------------------------------------------------
# single invoice
# --------------------------------------------------------------------------
def process_file(path: str | Path, master, seen: dict, erp_conn: erp.MockERP,
                 post_to_erp: bool = True) -> ProcessedInvoice:
    vendors, pos, grns = master
    path = Path(path)
    audit: list[str] = []

    result = ocr.read_image(str(path))
    audit.append(f"OCR via {ocr.engine_info()} — mean confidence {result.confidence:.1f}%")

    inv = extract.extract(result, source_file=path.name)
    audit.append(f"Extracted invoice {inv.invoice_number or '?'} "
                 f"(vendor '{inv.vendor_name}', total {inv.total:,.2f})")
    for w in inv.extraction_warnings:
        audit.append(f"  extraction warning: {w}")

    match = matching.match(inv, vendors, pos, grns, seen=seen)
    audit.append(f"Three-way match: {match.match_status}"
                 + (f" vs {match.matched_po}" if match.matched_po else ""))
    for d in match.discrepancies:
        audit.append(f"  [{d.severity}] {d.code}: {d.detail}")

    vendor, _ = matching.resolve_vendor(inv, vendors)
    dec = approvals.decide(inv, match, vendor)
    audit.append(f"Decision: {dec.action}"
                 + (f" -> {dec.approver_role}" if dec.approver_role else ""))

    if post_to_erp:
        entry = erp_conn.post_invoice(inv, dec, vendor)
        audit.append(f"Posted to ERP as {entry.erp_document}")
        if dec.payment_status == "SCHEDULED":
            ref = erp_conn.schedule_payment(entry)
            dec.erp_document = entry.erp_document
            audit.append(f"Payment {ref} scheduled for {entry.payment_date}")
        elif dec.action == "ROUTED":
            erp_conn.enqueue_for_approval(entry, dec)
            audit.append(f"Queued for {dec.approver_role} approval")

    dec.audit = audit
    return ProcessedInvoice(invoice=inv, match=match, decision=dec, vendor=vendor)


# --------------------------------------------------------------------------
# batch
# --------------------------------------------------------------------------
def process_directory(invoice_dir: Path | None = None, post_to_erp: bool = True):
    invoice_dir = invoice_dir or config.INVOICE_DIR
    master = load_master()
    erp_conn = erp.MockERP()
    seen: dict[tuple, str] = {}
    results: list[ProcessedInvoice] = []

    files = sorted(p for p in invoice_dir.iterdir()
                   if p.suffix.lower() in {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"})
    for i, f in enumerate(files):
        print(f"  [{i + 1}/{len(files)}] {f.name} ...", flush=True)
        results.append(process_file(f, master, seen, erp_conn, post_to_erp))
    return results, erp_conn
