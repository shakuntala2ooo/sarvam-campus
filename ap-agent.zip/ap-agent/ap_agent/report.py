"""Reporting: a console summary and a self-contained HTML dashboard."""
from __future__ import annotations

import html
from datetime import date

from . import config
from .models import ProcessedInvoice

_STATUS_CLASS = {
    "MATCHED": "ok", "PARTIAL": "warn", "EXCEPTION": "err",
    "NO_PO": "err", "UNMATCHED": "err",
}
_ACTION_CLASS = {
    "AUTO_APPROVED": "ok", "ROUTED": "warn", "HELD": "err",
    "REJECTED": "err", "MANUAL_CODING": "warn",
}


def _money(x: float) -> str:
    return f"{config.CURRENCY_SYMBOL}{x:,.2f}"


def score_against_truth(results, truth: dict) -> dict:
    """Field-level extraction accuracy vs the generator's ground truth."""
    fields = ["invoice_number", "po_number", "vendor_name"]
    hits = {f: 0 for f in fields}
    total = {f: 0 for f in fields}
    total_amt_ok = 0
    n = 0
    for r in results:
        g = truth.get(r.invoice.source_file)
        if not g:
            continue
        n += 1
        inv = r.invoice
        if inv.invoice_number == g["invoice_number"].upper().replace(" ", ""):
            hits["invoice_number"] += 1
        if inv.po_number == (g["po_number"] or ""):
            hits["po_number"] += 1
        if inv.vendor_name.upper().replace(" ", "") == g["vendor_name"].upper().replace(" ", ""):
            hits["vendor_name"] += 1
        if abs(inv.total - g["total"]) < 0.5:
            total_amt_ok += 1
    for f in fields:
        total[f] = n
    acc = {f: (hits[f] / n if n else 0) for f in fields}
    acc["total_amount"] = (total_amt_ok / n if n else 0)
    return {"n": n, "accuracy": acc}


# --------------------------------------------------------------------------
# console
# --------------------------------------------------------------------------
def render_console(results: list[ProcessedInvoice], erp_conn) -> str:
    lines = []
    lines.append("=" * 118)
    lines.append(" ACCOUNTS PAYABLE AGENT — RUN SUMMARY".ljust(118))
    lines.append("=" * 118)
    hdr = f"{'INVOICE':<16}{'VENDOR':<24}{'TOTAL':>15}  {'MATCH':<10}{'DECISION':<15}{'APPROVER':<15}{'PAYMENT':<12}"
    lines.append(hdr)
    lines.append("-" * 118)
    for r in results:
        inv, m, d = r.invoice, r.match, r.decision
        vname = (r.vendor.name if r.vendor else inv.vendor_name)[:23]
        pay = d.payment_status.replace("_", " ")
        if d.payment_status == "SCHEDULED" and d.payment_date:
            pay = f"{d.payment_date}"
        lines.append(
            f"{inv.invoice_number[:15]:<16}{vname:<24}{_money(inv.total):>15}  "
            f"{m.match_status:<10}{d.action:<15}{d.approver_role:<15}{pay:<12}"
        )
    lines.append("-" * 118)
    s = erp_conn.summary()
    n = len(results)
    auto = sum(1 for r in results if r.decision.action == "AUTO_APPROVED")
    routed = sum(1 for r in results if r.decision.action == "ROUTED")
    held = sum(1 for r in results if r.decision.action in ("HELD", "REJECTED"))
    manual = sum(1 for r in results if r.decision.action == "MANUAL_CODING")
    lines.append(f" Invoices processed : {n}")
    lines.append(f" Touchless (auto)   : {auto}  ({auto / n:.0%})" if n else "")
    lines.append(f" Routed to approver : {routed}")
    lines.append(f" Held / rejected    : {held}")
    lines.append(f" Manual coding      : {manual}")
    lines.append(f" Value scheduled    : {_money(s['value_scheduled'])}")
    lines.append(f" Value blocked      : {_money(s['value_blocked'])}")
    lines.append(f" ERP documents      : {s['documents_posted']}   Approval queue: {s['approval_queue']}")
    lines.append("=" * 118)
    return "\n".join(lines)


# --------------------------------------------------------------------------
# html
# --------------------------------------------------------------------------
def render_html(results: list[ProcessedInvoice], erp_conn, accuracy: dict | None = None) -> str:
    s = erp_conn.summary()
    n = len(results)
    auto = sum(1 for r in results if r.decision.action == "AUTO_APPROVED")
    routed = sum(1 for r in results if r.decision.action == "ROUTED")
    held = sum(1 for r in results if r.decision.action in ("HELD", "REJECTED"))
    manual = sum(1 for r in results if r.decision.action == "MANUAL_CODING")
    touchless = f"{auto / n:.0%}" if n else "0%"

    rows = []
    for r in results:
        inv, m, d = r.invoice, r.match, r.decision
        vname = html.escape(r.vendor.name if r.vendor else inv.vendor_name)
        discs = "<br>".join(
            f"<span class='sev {x.severity.lower()}'>{html.escape(x.code)}</span> {html.escape(x.detail)}"
            for x in m.discrepancies) or "<span class='muted'>none</span>"
        pay = html.escape(d.payment_status.replace("_", " ").title())
        pay_date = html.escape(d.payment_date) if (d.payment_status == "SCHEDULED" and d.payment_date) else ""
        rows.append(f"""
        <tr>
          <td class="mono">{html.escape(inv.invoice_number)}<div class="sub">{html.escape(inv.source_file)}</div></td>
          <td>{vname}<div class="sub">{html.escape(inv.vendor_gstin or '')}</div></td>
          <td class="num">{_money(inv.total)}</td>
          <td><span class="pill {_STATUS_CLASS.get(m.match_status, 'err')}">{m.match_status}</span>
              <div class="sub">{m.matched_po or '—'} · conf {m.confidence:.0%}</div></td>
          <td>{discs}</td>
          <td><span class="pill {_ACTION_CLASS.get(d.action, 'warn')}">{d.action.replace('_', ' ')}</span>
              <div class="sub">{html.escape(d.approver_role or '—')}</div></td>
          <td><div>{pay}</div>{"<div class='sub'>" + pay_date + "</div>" if pay_date else ""}<div class="sub mono">{html.escape(d.erp_document)}</div></td>
        </tr>""")

    acc_html = ""
    if accuracy and accuracy.get("n"):
        a = accuracy["accuracy"]
        items = [
            ("Invoice no.", a["invoice_number"]), ("PO number", a["po_number"]),
            ("Vendor name", a["vendor_name"]), ("Total amount", a["total_amount"]),
        ]
        acc_html = "<div class='acc'>" + "".join(
            f"<div class='acc-item'><div class='acc-v'>{v:.0%}</div><div class='acc-k'>{k}</div></div>"
            for k, v in items) + "</div>"

    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Accounts Payable Agent — Run Report</title>
<style>
  :root{{--bg:#f5f6f8;--card:#fff;--ink:#12161c;--muted:#6b7280;--line:#e5e7eb;
        --ok:#0f9d58;--warn:#e8a300;--err:#d93025;--brand:#1a56db}}
  *{{box-sizing:border-box}}
  body{{margin:0;font:14px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
       background:var(--bg);color:var(--ink)}}
  .wrap{{max-width:1240px;margin:0 auto;padding:32px 24px 64px}}
  header{{display:flex;justify-content:space-between;align-items:flex-end;gap:16px;flex-wrap:wrap}}
  h1{{font-size:22px;margin:0}}
  .sub{{color:var(--muted);font-size:12px}}
  td .sub{{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}}
  .mono{{font-family:ui-monospace,SFMono-Regular,Menlo,monospace}}
  .cards{{display:flex;flex-wrap:wrap;gap:12px;margin:24px 0}}
  .card{{flex:1 1 160px;background:var(--card);border:1px solid var(--line);border-radius:12px;padding:16px}}
  .card .v{{font-size:24px;font-weight:650}}
  .card .k{{color:var(--muted);font-size:12px;margin-top:2px}}
  .card.hl{{background:linear-gradient(180deg,#eef4ff,#fff);border-color:#c7d7ff}}
  .acc{{display:flex;flex-wrap:wrap;gap:12px;margin:0 0 24px}}
  .acc-item{{flex:1 1 160px;background:#fff;border:1px solid var(--line);border-radius:10px;padding:12px 16px}}
  .acc-v{{font-size:20px;font-weight:650;color:var(--ok)}}
  .acc-k{{color:var(--muted);font-size:12px}}
  table{{width:100%;border-collapse:collapse;background:var(--card);border:1px solid var(--line);
        border-radius:12px;overflow:hidden;table-layout:fixed}}
  th,td{{text-align:left;padding:12px 12px;border-bottom:1px solid var(--line);vertical-align:top;
        overflow-wrap:anywhere}}
  th{{background:#fafbfc;font-size:11px;letter-spacing:.06em;text-transform:uppercase;color:var(--muted)}}
  tr:last-child td{{border-bottom:none}}
  td.num{{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}}
  .pill{{display:inline-block;padding:2px 9px;border-radius:999px;font-size:11px;font-weight:600}}
  .pill.ok{{background:#e6f4ea;color:var(--ok)}}
  .pill.warn{{background:#fef7e0;color:#9a6b00}}
  .pill.err{{background:#fce8e6;color:var(--err)}}
  .sev{{font-weight:600;font-size:11px}}
  .sev.error{{color:var(--err)}} .sev.warn{{color:#9a6b00}} .sev.info{{color:var(--muted)}}
  .muted{{color:var(--muted)}}
  .section-title{{margin:32px 0 12px;font-size:13px;font-weight:650;color:var(--muted);
                 letter-spacing:.06em;text-transform:uppercase}}
  footer{{margin-top:28px;color:var(--muted);font-size:12px}}
</style></head>
<body><div class="wrap">
  <header>
    <div>
      <h1>Accounts Payable Agent — Run Report</h1>
      <div class="sub">Invoice extraction · three-way match · approval &amp; payment automation</div>
    </div>
    <div class="sub">Generated {date.today().isoformat()} · {n} invoices · mock ERP</div>
  </header>

  <div class="cards">
    <div class="card hl"><div class="v">{touchless}</div><div class="k">Touchless rate</div></div>
    <div class="card"><div class="v">{auto}</div><div class="k">Auto-approved &amp; paid</div></div>
    <div class="card"><div class="v">{routed}</div><div class="k">Routed to approver</div></div>
    <div class="card"><div class="v">{held}</div><div class="k">Held / rejected</div></div>
    <div class="card"><div class="v">{manual}</div><div class="k">Manual coding</div></div>
    <div class="card"><div class="v">{_money(s['value_scheduled'])}</div><div class="k">Value scheduled</div></div>
  </div>

  {acc_html}

  <div class="section-title">Invoice ledger</div>
  <table>
    <colgroup>
      <col style="width:11%"><col style="width:15%"><col style="width:9%"><col style="width:11%">
      <col style="width:31%"><col style="width:12%"><col style="width:11%">
    </colgroup>
    <thead><tr>
      <th>Invoice</th><th>Vendor</th><th class="num">Amount</th><th>Match</th>
      <th>Discrepancies</th><th>Decision</th><th>Payment</th>
    </tr></thead>
    <tbody>{''.join(rows)}</tbody>
  </table>

  <footer>
    {s['documents_posted']} ERP documents posted · {s['approval_queue']} awaiting approval ·
    {_money(s['value_blocked'])} blocked pending resolution.
    Every figure above is produced by the agent from OCR'd scanned invoices.
  </footer>
</div></body></html>"""
