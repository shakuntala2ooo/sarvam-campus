#!/usr/bin/env python3
"""Accounts Payable Agent — demo runner.

Usage:
    python run_demo.py                      # process data/invoices/*.png
    python run_demo.py --invoices DIR       # process a folder of scans
    python run_demo.py --file scan.png      # process one scan
    python run_demo.py --no-erp             # analyse only, don't post to ERP
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from ap_agent import config, erp, ocr, pipeline, report


def main() -> None:
    ap = argparse.ArgumentParser(description="Accounts Payable Agent demo")
    ap.add_argument("--invoices", type=Path, default=config.INVOICE_DIR,
                    help="folder of scanned invoice images")
    ap.add_argument("--file", type=Path, default=None, help="process a single image")
    ap.add_argument("--out", type=Path, default=config.OUT_DIR, help="output folder")
    ap.add_argument("--no-erp", action="store_true", help="do not post to the mock ERP")
    args = ap.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)

    try:
        ocr.ensure_engine()
    except ocr.OCREngineError as e:
        raise SystemExit(f"\n[setup] {e}\n")

    print(f"OCR engine   : {ocr.engine_info()}")
    print(f"Tesseract cmd: {config.TESSERACT_CMD}")
    print(f"Auto-approve : up to {config.CURRENCY_SYMBOL}{config.AUTO_APPROVE_LIMIT:,.0f}")
    print("-" * 118)

    master = pipeline.load_master()
    erp_conn = erp.MockERP()
    seen: dict = {}
    results = []

    if args.file:
        print(f"  processing {args.file.name} ...", flush=True)
        results.append(pipeline.process_file(args.file, master, seen, erp_conn,
                                             post_to_erp=not args.no_erp))
    else:
        files = sorted(p for p in args.invoices.iterdir()
                       if p.suffix.lower() in {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"})
        for i, f in enumerate(files):
            print(f"  [{i + 1}/{len(files)}] {f.name} ...", flush=True)
            results.append(pipeline.process_file(f, master, seen, erp_conn,
                                                 post_to_erp=not args.no_erp))

    print()
    print(report.render_console(results, erp_conn))

    # ---- extraction accuracy vs ground truth ---------------------------
    truth_path = config.DATA_DIR / "ground_truth.json"
    accuracy = None
    if truth_path.exists():
        truth = json.loads(truth_path.read_text())
        accuracy = report.score_against_truth(results, truth)
        a = accuracy["accuracy"]
        print("\n Extraction accuracy vs ground truth:")
        print(f"   invoice number {a['invoice_number']:.0%} | PO number {a['po_number']:.0%} | "
              f"vendor name {a['vendor_name']:.0%} | total amount {a['total_amount']:.0%}")

    # ---- artifacts -----------------------------------------------------
    (args.out / "processed.json").write_text(
        json.dumps([r.to_dict() for r in results], indent=2))
    if not args.no_erp:
        erp_conn.save(args.out / "erp_ledger.json")
    html = report.render_html(results, erp_conn, accuracy)
    (args.out / "report.html").write_text(html)
    print(f"\n Artifacts written to {args.out}/  (report.html, processed.json, erp_ledger.json)")


if __name__ == "__main__":
    main()
