"""Unit tests for the AP agent — no OCR needed (fast).

Run:  python -m unittest discover -s tests
"""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from ap_agent import approvals, matching, pipeline  # noqa: E402
from ap_agent.extract import extract  # noqa: E402
from ap_agent.models import Invoice, InvoiceLine  # noqa: E402
from ap_agent.ocr import OCRResult  # noqa: E402

MASTER = pipeline.load_master()
VENDORS, POS, GRNS = MASTER


SAMPLE_TEXT = """ACME SUPPLIES PVT LTD
14 Park Street, Kolkata 700016, West Bengal
GSTIN: 19AABCA1234F1Z5
TAX INVOICE
Invoice No: INV-2024-0912
Invoice Date: 2026-08-21
PO Number: PO-4471
Due Date: 2026-09-20
Description Qty Unit Price Amount
A4 Copier Paper 75gsm Ream 100 250.00 25,000.00
Printer Toner Cartridge Black 5 3,200.00 16,000.00
Subtotal 41,000.00
GST @ 18% 7,380.00
Total 48,380.00
Payment Terms: Net 30 days
Authorised Signatory"""


class TestExtraction(unittest.TestCase):
    def setUp(self):
        lines = [l for l in SAMPLE_TEXT.splitlines() if l.strip()]
        self.ocr = OCRResult(text=SAMPLE_TEXT, confidence=92.0, lines=lines)

    def test_header_fields(self):
        inv = extract(self.ocr)
        self.assertEqual(inv.invoice_number, "INV-2024-0912")
        self.assertEqual(inv.po_number, "PO-4471")
        self.assertEqual(inv.vendor_name, "ACME SUPPLIES PVT LTD")
        self.assertEqual(inv.vendor_gstin, "19AABCA1234F1Z5")
        self.assertEqual(inv.invoice_date, "2026-08-21")
        self.assertEqual(inv.due_date, "2026-09-20")

    def test_amounts_and_lines(self):
        inv = extract(self.ocr)
        self.assertAlmostEqual(inv.subtotal, 41000.00)
        self.assertAlmostEqual(inv.tax, 7380.00)
        self.assertAlmostEqual(inv.total, 48380.00)
        self.assertEqual(len(inv.lines), 2)
        self.assertAlmostEqual(inv.lines[0].qty, 100)
        self.assertAlmostEqual(inv.lines[1].amount, 16000.00)
        self.assertEqual(inv.extraction_warnings, [])


def _inv(**kw):
    base = dict(invoice_number="INV-1", vendor_name="ACME SUPPLIES PVT LTD",
                po_number="PO-4471", total=1000.0, subtotal=847.0, tax=153.0)
    base.update(kw)
    return Invoice(**base)


class TestMatching(unittest.TestCase):
    def test_clean_match(self):
        inv = _inv(lines=[InvoiceLine("A4 Copier Paper 75gsm Ream", 100, 250.00, 25000.0),
                          InvoiceLine("Printer Toner Cartridge Black", 5, 3200.00, 16000.0)],
                   subtotal=41000.0, tax=7380.0, total=48380.0)
        res = matching.match(inv, VENDORS, POS, GRNS, seen={})
        self.assertEqual(res.match_status, "MATCHED")
        self.assertFalse(res.has_errors)

    def test_price_variance_flagged(self):
        inv = _inv(vendor_name="BLUEWAVE LOGISTICS LTD", po_number="PO-4482",
                   lines=[InvoiceLine("Freight Domestic Route A", 10, 8925.00, 89250.0)])
        res = matching.match(inv, VENDORS, POS, GRNS, seen={})
        codes = {d.code for d in res.discrepancies}
        self.assertIn("PRICE_VARIANCE", codes)
        self.assertEqual(res.match_status, "PARTIAL")

    def test_over_receipt_is_error(self):
        inv = _inv(vendor_name="ORION ELECTRONICS INDIA", po_number="PO-4490",
                   lines=[InvoiceLine("LED Panel Light 24 inch", 60, 6000.00, 360000.0),
                          InvoiceLine("HDMI Cable 2m", 100, 350.00, 35000.0)])
        res = matching.match(inv, VENDORS, POS, GRNS, seen={})
        self.assertIn("OVER_RECEIPT", {d.code for d in res.discrepancies})
        self.assertTrue(res.has_errors)

    def test_missing_po(self):
        inv = _inv(po_number="")
        res = matching.match(inv, VENDORS, POS, GRNS, seen={})
        self.assertEqual(res.match_status, "NO_PO")
        self.assertIn("MISSING_PO", {d.code for d in res.discrepancies})

    def test_duplicate_detected_on_second_sighting(self):
        seen = {}
        inv = _inv(invoice_number="INV-DUP", lines=[InvoiceLine("A4 Copier Paper 75gsm Ream", 100, 250.0, 25000.0)])
        matching.match(inv, VENDORS, POS, GRNS, seen=seen)          # first sighting
        res2 = matching.match(inv, VENDORS, POS, GRNS, seen=seen)   # second
        self.assertIn("DUPLICATE_INVOICE", {d.code for d in res2.discrepancies})


class TestApprovals(unittest.TestCase):
    def test_small_clean_auto_approves_and_schedules(self):
        inv = _inv(total=48_380.0, due_date="2099-01-01")
        res = matching.MatchResult(match_status="MATCHED")
        dec = approvals.decide(inv, res, VENDORS["V-1001"])
        self.assertEqual(dec.action, "AUTO_APPROVED")
        self.assertEqual(dec.payment_status, "SCHEDULED")

    def test_large_clean_routes_to_controller(self):
        inv = _inv(total=1_416_000.0)
        dec = approvals.decide(inv, matching.MatchResult(match_status="MATCHED"), VENDORS["V-1005"])
        self.assertEqual(dec.action, "ROUTED")
        self.assertEqual(dec.approver_role, "CONTROLLER")
        self.assertEqual(dec.payment_status, "BLOCKED")

    def test_duplicate_is_held(self):
        inv = _inv()
        from ap_agent.models import Discrepancy
        m = matching.MatchResult(match_status="EXCEPTION",
                                 discrepancies=[Discrepancy("DUPLICATE_INVOICE", "ERROR", "dup")])
        dec = approvals.decide(inv, m, VENDORS["V-1001"])
        self.assertEqual(dec.action, "HELD")
        self.assertEqual(dec.payment_status, "BLOCKED")


if __name__ == "__main__":
    unittest.main(verbosity=2)
