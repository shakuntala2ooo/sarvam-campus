"""Generate synthetic *scanned* invoice images for the demo.

Each scenario is rendered as a realistic tax invoice, then degraded
(slight rotation, noise, blur) to look like a real scanner output, and
saved as a PNG. A ground-truth JSON is written alongside so the demo can
score extraction accuracy.

Run:  python tools/generate_invoices.py
"""
from __future__ import annotations

import json
import random
from datetime import date, timedelta
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_ROOT / "data"
INVOICE_DIR = DATA_DIR / "invoices"

FONT_REG = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FONT_BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"

W, H = 1000, 1320
GST_RATE = 0.18


def inr(x: float) -> str:
    """Indian-style grouping: 12,34,567.89"""
    neg = x < 0
    x = abs(x)
    whole = int(x)
    frac = f"{x - whole:.2f}"[1:]  # ".89"
    s = str(whole)
    if len(s) > 3:
        head, tail = s[:-3], s[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        s = ",".join(parts) + "," + tail
    return ("-" if neg else "") + s + frac


# --------------------------------------------------------------------------
# Scenario definitions (ground truth)
# --------------------------------------------------------------------------
def _inv(number, vdate, vendor_name, gstin, address, po, lines, terms=30,
         scenario="", note=""):
    subtotal = round(sum(l["qty"] * l["unit_price"] for l in lines), 2)
    tax = round(subtotal * GST_RATE, 2)
    total = round(subtotal + tax, 2)
    d = date.fromisoformat(vdate)
    return {
        "invoice_number": number,
        "invoice_date": vdate,
        "due_date": (d + timedelta(days=terms)).isoformat(),
        "vendor_name": vendor_name,
        "vendor_gstin": gstin,
        "vendor_address": address,
        "po_number": po,
        "terms_days": terms,
        "lines": lines,
        "subtotal": subtotal,
        "tax": tax,
        "total": total,
        "scenario": scenario,
        "note": note,
    }


SCENARIOS = [
    _inv("INV-2024-0912", "2026-08-21", "ACME SUPPLIES PVT LTD", "19AABCA1234F1Z5",
         "14 Park Street, Kolkata 700016, West Bengal", "PO-4471",
         [{"description": "A4 Copier Paper 75gsm Ream", "qty": 100, "unit_price": 250.00},
          {"description": "Printer Toner Cartridge Black", "qty": 5, "unit_price": 3200.00}],
         scenario="clean_auto_approve",
         note="Clean three-way match, within auto-approval limit"),

    _inv("INV-2024-0918", "2026-08-26", "BLUEWAVE LOGISTICS LTD", "27AABCB5678K1Z2",
         "Plot 22 MIDC, Pune 411018, Maharashtra", "PO-4482",
         [{"description": "Freight Domestic Route A", "qty": 10, "unit_price": 8925.00}],
         terms=45, scenario="price_variance",
         note="Billed unit price 5% above PO price"),

    _inv("INV-2024-0921", "2026-08-29", "ORION ELECTRONICS INDIA", "29AABCO9012M1Z9",
         "88 Electronic City, Bengaluru 560100, Karnataka", "PO-4490",
         [{"description": "LED Panel Light 24 inch", "qty": 60, "unit_price": 6000.00},
          {"description": "HDMI Cable 2m", "qty": 100, "unit_price": 350.00}],
         scenario="qty_over_receipt",
         note="Invoiced 60 LED panels but only 50 were received"),

    _inv("INV-2024-0925", "2026-09-02", "GREENTECH FACILITY MGMT", "33AABCG1122T1Z4",
         "5 Anna Salai, Chennai 600002, Tamil Nadu", "",
         [{"description": "Housekeeping Services Aug 2026", "qty": 1, "unit_price": 45000.00}],
         scenario="missing_po",
         note="No purchase order referenced"),

    _inv("INV-2024-0912", "2026-08-21", "ACME SUPPLIES PVT LTD", "19AABCA1234F1Z5",
         "14 Park Street, Kolkata 700016, West Bengal", "PO-4471",
         [{"description": "A4 Copier Paper 75gsm Ream", "qty": 100, "unit_price": 250.00},
          {"description": "Printer Toner Cartridge Black", "qty": 5, "unit_price": 3200.00}],
         scenario="duplicate",
         note="Resubmitted copy of INV-2024-0912"),

    _inv("INV-2024-0930", "2026-09-04", "PIONEER PACKAGING CO", "07AABCP3456Q1Z1",
         "31 Okhla Phase II, New Delhi 110020", "PO-4501",
         [{"description": "Corrugated Box Large 5-ply", "qty": 5000, "unit_price": 42.00},
          {"description": "Bubble Wrap Roll 1m x 100m", "qty": 200, "unit_price": 600.00}],
         terms=15, scenario="clean_manager",
         note="Clean match but above auto-approval limit"),

    _inv("INV-2024-0933", "2026-09-06", "ACME SUPPLIES PVT LTD", "19AABCA1234F1Z5",
         "14 Park Street, Kolkata 700016, West Bengal", "PO-4520",
         [{"description": "A4 Copier Paper 75gsm Ream", "qty": 40, "unit_price": 250.00}],
         scenario="closed_po",
         note="References a purchase order that is already closed"),

    _inv("INV-2024-0936", "2026-09-09", "SUNRISE IT SERVICES", "36AABCS7890R1Z7",
         "7 Banjara Hills, Hyderabad 500034, Telangana", "PO-4515",
         [{"description": "Annual ERP License Enterprise", "qty": 1, "unit_price": 1200000.00}],
         scenario="clean_controller",
         note="Clean match, requires controller approval by value"),
]


def _font(path, size):
    return ImageFont.truetype(path, size)


def render(inv: dict, seed: int) -> Image.Image:
    rng = random.Random(seed)
    img = Image.new("RGB", (W, H), "white")
    d = ImageDraw.Draw(img)

    f_vendor = _font(FONT_BOLD, 26)
    f_small = _font(FONT_REG, 15)
    f_title = _font(FONT_BOLD, 22)
    f_head = _font(FONT_BOLD, 15)
    f_row = _font(FONT_REG, 15)
    f_bold = _font(FONT_BOLD, 15)

    x0 = 60
    d.text((x0, 40), inv["vendor_name"], fill="black", font=f_vendor)
    d.text((x0, 78), inv["vendor_address"], fill="black", font=f_small)
    d.text((x0, 100), f"GSTIN: {inv['vendor_gstin']}", fill="black", font=f_small)

    d.text((W // 2 - 70, 150), "TAX INVOICE", fill="black", font=f_title)
    d.line([(x0, 185), (W - 60, 185)], fill="black", width=2)

    # header meta block
    left = [
        f"Invoice No: {inv['invoice_number']}",
        f"Invoice Date: {inv['invoice_date']}",
        f"PO Number: {inv['po_number'] or '-'}",
        f"Due Date: {inv['due_date']}",
    ]
    y = 200
    for t in left:
        d.text((x0, y), t, fill="black", font=f_row)
        y += 26

    # table header
    ty = 330
    d.line([(x0, ty - 8), (W - 60, ty - 8)], fill="black", width=1)
    d.text((x0, ty), "Description", fill="black", font=f_head)
    d.text((610, ty), "Qty", fill="black", font=f_head)
    d.text((730, ty), "Unit Price", fill="black", font=f_head)
    d.text((880, ty), "Amount", fill="black", font=f_head)
    d.line([(x0, ty + 24), (W - 60, ty + 24)], fill="black", width=1)

    ry = ty + 34
    for l in inv["lines"]:
        amt = l["qty"] * l["unit_price"]
        d.text((x0, ry), l["description"][:46], fill="black", font=f_row)
        d.text((620, ry), f"{l['qty']:g}", fill="black", font=f_row)
        d.text((720, ry), inr(l["unit_price"]), fill="black", font=f_row)
        d.text((870, ry), inr(amt), fill="black", font=f_row)
        ry += 30

    d.line([(x0, ry + 4), (W - 60, ry + 4)], fill="black", width=1)

    # totals block (right aligned)
    sy = ry + 20
    d.text((720, sy), "Subtotal", fill="black", font=f_bold)
    d.text((870, sy), inr(inv["subtotal"]), fill="black", font=f_bold)
    d.text((720, sy + 28), "GST @ 18%", fill="black", font=f_bold)
    d.text((870, sy + 28), inr(inv["tax"]), fill="black", font=f_bold)
    d.line([(700, sy + 52), (W - 60, sy + 52)], fill="black", width=1)
    d.text((720, sy + 60), "Total", fill="black", font=f_bold)
    d.text((860, sy + 60), inr(inv["total"]), fill="black", font=f_bold)

    # footer
    d.text((x0, H - 150), "Payment Terms: Net %d days" % inv["terms_days"], fill="black", font=f_small)
    d.text((x0, H - 120), "Bank: See remittance advice / GSTIN as above", fill="black", font=f_small)
    d.text((x0, H - 60), "Authorised Signatory", fill="black", font=f_small)

    # ---- degrade to look scanned ----
    # pad so the slight rotation cannot clip the top/bottom text lines
    pad = 24
    canvas = Image.new("RGB", (W + 2 * pad, H + 2 * pad), "white")
    canvas.paste(img, (pad, pad))
    img = canvas
    img = img.rotate(rng.uniform(-0.7, 0.7), resample=Image.BICUBIC, expand=True, fillcolor="white")
    img = img.filter(ImageFilter.GaussianBlur(rng.uniform(0.4, 0.9)))
    px = img.load()
    W2, H2 = img.size
    for _ in range(int(W2 * H2 * 0.02)):
        xx = rng.randint(0, W2 - 1)
        yy = rng.randint(0, H2 - 1)
        r, g, b = px[xx, yy]
        n = rng.randint(-35, 35)
        px[xx, yy] = (max(0, min(255, r + n)), max(0, min(255, g + n)), max(0, min(255, b + n)))
    return img


def main():
    INVOICE_DIR.mkdir(parents=True, exist_ok=True)
    truth = {}
    for i, inv in enumerate(SCENARIOS):
        fname = f"{i + 1:02d}_{inv['scenario']}.png"
        render(inv, seed=1000 + i).save(INVOICE_DIR / fname)
        truth[fname] = inv
        print(f"  rendered {fname}  ({inv['vendor_name']} / {inv['invoice_number']} / {inr(inv['total'])})")
    (DATA_DIR / "ground_truth.json").write_text(json.dumps(truth, indent=2))
    print(f"\n{len(SCENARIOS)} invoice images -> {INVOICE_DIR}")


if __name__ == "__main__":
    main()
