#!/usr/bin/env python3
"""Rebuild report.html from a previous run's processed.json — no re-OCR.

Usage: python tools/rebuild_report.py [out_dir]
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from ap_agent import config, report  # noqa: E402
from ap_agent.erp import ERPEntry, MockERP  # noqa: E402
from ap_agent.models import (Decision, Discrepancy, Invoice, InvoiceLine,  # noqa: E402
                             MatchResult, ProcessedInvoice, Vendor)


def _load(out_dir: Path):
    raw = json.loads((out_dir / "processed.json").read_text())
    results = []
    for r in raw:
        inv = Invoice(**r["invoice"])
        inv.lines = [InvoiceLine(**l) for l in r["invoice"].get("lines", [])]
        m = r["match"]
        match = MatchResult(match_status=m["match_status"], matched_po=m.get("matched_po"),
                            matched_grns=m.get("matched_grns", []),
                            discrepancies=[Discrepancy(**d) for d in m.get("discrepancies", [])],
                            confidence=m.get("confidence", 0.0))
        dec = Decision(**r["decision"])
        vendor = Vendor(**r["vendor"]) if r.get("vendor") else None
        results.append(ProcessedInvoice(invoice=inv, match=match, decision=dec, vendor=vendor))

    erp_conn = MockERP()
    led = out_dir / "erp_ledger.json"
    if led.exists():
        data = json.loads(led.read_text())
        for e in data.get("entries", []):
            erp_conn.entries.append(ERPEntry(**e))
        erp_conn.queue = data.get("approval_queue", [])
    return results, erp_conn


def main():
    out_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else config.OUT_DIR
    results, erp_conn = _load(out_dir)
    truth = json.loads((config.DATA_DIR / "ground_truth.json").read_text())
    accuracy = report.score_against_truth(results, truth)
    (out_dir / "report.html").write_text(report.render_html(results, erp_conn, accuracy))
    print(f"rebuilt {out_dir / 'report.html'} from {len(results)} results")


if __name__ == "__main__":
    main()
